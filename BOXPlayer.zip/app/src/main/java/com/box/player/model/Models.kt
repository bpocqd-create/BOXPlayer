package com.box.player.model

import com.google.gson.annotations.SerializedName

data class SeriesItem(
    @SerializedName("id") val id: String,
    @SerializedName("name") val name: String,
    @SerializedName("path") val path: String,
    @SerializedName("lastEpisodePath") var lastEpisodePath: String = "",
    @SerializedName("lastSeasonIndex") var lastSeasonIndex: Int = 0,
    @SerializedName("episodesProgress") var episodesProgress: MutableMap<String, Double> = mutableMapOf(),
    @SerializedName("seasonsMemory") var seasonsMemory: MutableMap<String, String> = mutableMapOf()
)

data class SeasonInfo(
    val displayName: String,
    val path: String
)

data class EpisodeInfo(
    val displayName: String,
    val fullPath: String
)

data class SubtitleEntry(
    val start: Long,  // milliseconds
    val end: Long,    // milliseconds
    val text: String
)
