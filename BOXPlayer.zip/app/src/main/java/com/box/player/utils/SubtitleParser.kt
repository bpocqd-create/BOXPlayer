package com.box.player.utils

import com.box.player.model.SubtitleEntry
import java.io.File

object SubtitleParser {

    fun parse(file: File): List<SubtitleEntry> {
        return when (file.extension.lowercase()) {
            "srt" -> parseSrt(file)
            "ass", "ssa" -> parseAss(file)
            else -> emptyList()
        }
    }

    private fun parseSrt(file: File): List<SubtitleEntry> {
        val entries = mutableListOf<SubtitleEntry>()
        try {
            val content = file.readText(Charsets.UTF_8)
            val blocks = content.trim().split(Regex("""\r?\n\r?\n"""))
            for (block in blocks) {
                val lines = block.trim().split(Regex("""\r?\n"""))
                val timeLineIdx = lines.indexOfFirst { it.contains("-->") }
                if (timeLineIdx < 0) continue
                val timeParts = lines[timeLineIdx].split(" --> ")
                if (timeParts.size != 2) continue
                val start = parseSrtTime(timeParts[0].trim()) ?: continue
                val end = parseSrtTime(timeParts[1].trim()) ?: continue
                val text = lines.drop(timeLineIdx + 1).joinToString("\n")
                    .trim()
                    .replace(Regex("<[^>]+>"), "")
                if (text.isNotBlank()) entries.add(SubtitleEntry(start, end, text))
            }
        } catch (e: Exception) { }
        return entries
    }

    private fun parseSrtTime(s: String): Long? {
        return try {
            val clean = s.replace(',', '.')
            val parts = clean.split(":")
            val h = parts[0].toLong()
            val m = parts[1].toLong()
            val secParts = parts[2].split(".")
            val sec = secParts[0].toLong()
            val ms = secParts.getOrElse(1) { "0" }.padEnd(3, '0').take(3).toLong()
            h * 3600000L + m * 60000L + sec * 1000L + ms
        } catch (e: Exception) { null }
    }

    private fun parseAss(file: File): List<SubtitleEntry> {
        val entries = mutableListOf<SubtitleEntry>()
        try {
            val lines = file.readLines(Charsets.UTF_8)
            var inEvents = false
            var startIdx = -1; var endIdx = -1; var textIdx = -1

            for (line in lines) {
                if (line.trim().equals("[Events]", ignoreCase = true)) { inEvents = true; continue }
                if (!inEvents) continue
                if (line.startsWith("[") && !line.contains("Events")) break

                if (line.startsWith("Format:")) {
                    val fields = line.substring(7).split(",").map { it.trim() }
                    startIdx = fields.indexOf("Start")
                    endIdx = fields.indexOf("End")
                    textIdx = fields.indexOf("Text")
                    continue
                }

                if (line.startsWith("Dialogue:") && startIdx >= 0 && endIdx >= 0 && textIdx >= 0) {
                    val parts = line.substring(9).split(",", limit = textIdx + 2)
                    if (parts.size <= textIdx) continue
                    val start = parseAssTime(parts[startIdx].trim()) ?: continue
                    val end = parseAssTime(parts[endIdx].trim()) ?: continue
                    var text = parts.drop(textIdx).joinToString(",").trim()
                    text = text.replace(Regex("""\{[^}]*\}"""), "")
                        .replace("""\N""", "\n").replace("""\n""", "\n")
                    if (text.isNotBlank()) entries.add(SubtitleEntry(start, end, text))
                }
            }
        } catch (e: Exception) { }
        return entries.sortedBy { it.start }
    }

    private fun parseAssTime(s: String): Long? {
        return try {
            val parts = s.split(":")
            val h = parts[0].toLong()
            val m = parts[1].toLong()
            val secParts = parts[2].split(".")
            val sec = secParts[0].toLong()
            val cs = secParts.getOrElse(1) { "0" }.padEnd(2, '0').take(2).toLong()
            h * 3600000L + m * 60000L + sec * 1000L + cs * 10L
        } catch (e: Exception) { null }
    }

    fun getSubtitleAt(entries: List<SubtitleEntry>, positionMs: Long, delayMs: Long): String {
        val adjustedPos = positionMs - delayMs
        return entries.firstOrNull { adjustedPos >= it.start && adjustedPos <= it.end }?.text ?: ""
    }
}
