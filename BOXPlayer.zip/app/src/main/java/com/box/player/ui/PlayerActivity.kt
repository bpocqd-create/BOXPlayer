package com.box.player.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.box.player.R
import com.box.player.databinding.ActivityPlayerBinding
import com.box.player.model.EpisodeInfo
import com.box.player.model.SeasonInfo
import com.box.player.model.SeriesItem
import com.box.player.model.SubtitleEntry
import com.box.player.utils.DataManager
import com.box.player.utils.FileScanner
import com.box.player.utils.SubtitleParser
import java.io.File

class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private var player: ExoPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var seriesItem: SeriesItem
    private var seasons = listOf<SeasonInfo>()
    private var episodes = listOf<EpisodeInfo>()
    private var currentSeasonIndex = 0
    private var currentEpisodeIndex = 0

    // Subtitle
    private var subtitles = listOf<SubtitleEntry>()
    private var subtitlesEnabled = false
    private var subtitleDelayMs = 0L
    private var subtitleFontSize = 26f

    private var controlsVisible = true
    private val hideControlsRunnable = Runnable { hideControls() }

    private val pickSubtitleLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri -> uri?.let { loadSubtitleFromUri(it) } }

    // Subtitle update runnable
    private val subtitleRunnable = object : Runnable {
        override fun run() {
            updateSubtitle()
            handler.postDelayed(this, 100)
        }
    }

    // Progress save runnable
    private val saveRunnable = object : Runnable {
        override fun run() {
            saveProgress()
            handler.postDelayed(this, 30000)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUI()

        val seriesId = intent.getStringExtra("series_id") ?: ""
        val seriesPath = intent.getStringExtra("series_path") ?: ""
        val seriesName = intent.getStringExtra("series_name") ?: ""

        val allSeries = DataManager.loadSeries(this)
        seriesItem = allSeries.find { it.id == seriesId }
            ?: SeriesItem(seriesId, seriesName, seriesPath)

        setupPlayer()
        loadSeasons()
        setupUI()
        setupGestures()
    }

    private fun setupPlayer() {
        player = ExoPlayer.Builder(this).build()
        binding.playerView.player = player
        binding.playerView.useController = false

        player?.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) onEpisodeEnded()
                updatePlayPauseBtn()
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePlayPauseBtn()
            }
        })
    }

    private fun loadSeasons() {
        seasons = FileScanner.loadSeasons(seriesItem.path)
        if (seasons.isEmpty()) { finish(); return }

        // ضع أسماء المواسم في الـ spinner
        val names = seasons.map { it.displayName }
        val spinnerAdapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerSeasons.adapter = spinnerAdapter

        // استرجع آخر موسم
        val lastSeasonIdx = seriesItem.lastSeasonIndex.coerceIn(0, seasons.size - 1)

        binding.spinnerSeasons.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                currentSeasonIndex = position
                seriesItem.lastSeasonIndex = position
                loadEpisodes(seasons[position])
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        binding.spinnerSeasons.setSelection(lastSeasonIdx)
    }

    private fun loadEpisodes(season: SeasonInfo) {
        episodes = FileScanner.loadEpisodes(season.path)
        if (episodes.isEmpty()) return

        val adapter = android.widget.ArrayAdapter(this,
            android.R.layout.simple_list_item_1,
            episodes.map { it.displayName })
        binding.listEpisodes.adapter = adapter

        binding.listEpisodes.setOnItemClickListener { _, _, position, _ ->
            playEpisode(position)
        }

        // استرجع آخر حلقة أو ابدأ من الأول
        val lastPath = seriesItem.seasonsMemory[season.path]
        val targetIdx = if (!lastPath.isNullOrEmpty()) {
            episodes.indexOfFirst { it.fullPath == lastPath }.takeIf { it >= 0 } ?: 0
        } else 0

        playEpisode(targetIdx)
    }

    private fun playEpisode(index: Int) {
        if (index < 0 || index >= episodes.size) return
        saveProgress()
        currentEpisodeIndex = index

        val ep = episodes[index]
        val file = File(ep.fullPath)
        if (!file.exists()) { showToast("File not found"); return }

        binding.listEpisodes.setItemChecked(index, true)
        binding.listEpisodes.smoothScrollToPosition(index)

        val mediaItem = MediaItem.fromUri(Uri.fromFile(file))
        player?.setMediaItem(mediaItem)
        player?.prepare()

        // استرجع موضع الحلقة
        val savedPos = seriesItem.episodesProgress[ep.fullPath] ?: 0.0
        if (savedPos > 0) player?.seekTo(savedPos.toLong())

        player?.play()

        // حفظ المعلومات
        seriesItem.lastEpisodePath = ep.fullPath
        seriesItem.seasonsMemory[seasons[currentSeasonIndex].path] = ep.fullPath

        // ترجمة تلقائية
        autoLoadSubtitle(ep.fullPath)
    }

    private fun autoLoadSubtitle(videoPath: String) {
        val subFile = FileScanner.findSubtitleForVideo(videoPath)
        if (subFile != null) {
            subtitles = SubtitleParser.parse(subFile)
            subtitlesEnabled = subtitles.isNotEmpty()
            updateCcButton()
            if (subtitlesEnabled) showToast("📄 ${subFile.name}")
        } else {
            subtitles = emptyList()
            subtitlesEnabled = false
            binding.tvSubtitle.text = ""
            updateCcButton()
        }
    }

    private fun loadSubtitleFromUri(uri: Uri) {
        try {
            val stream = contentResolver.openInputStream(uri) ?: return
            val ext = contentResolver.getType(uri)?.substringAfterLast("/") ?: "srt"
            val tmpFile = File(cacheDir, "subtitle.$ext")
            tmpFile.outputStream().use { stream.copyTo(it) }
            subtitles = SubtitleParser.parse(tmpFile)
            subtitlesEnabled = subtitles.isNotEmpty()
            subtitleDelayMs = 0L
            binding.seekSubDelay.progress = 20 // وسط = 0
            binding.tvSubDelay.text = "0.0s"
            updateCcButton()
            if (subtitlesEnabled) showToast("✅ Subtitle loaded")
        } catch (e: Exception) {
            showToast("❌ Cannot load subtitle")
        }
    }

    private fun setupUI() {
        // أزرار التحكم
        binding.btnPlayPause.setOnClickListener { togglePlayPause() }
        binding.btnPrev.setOnClickListener { prevEpisode() }
        binding.btnNext.setOnClickListener { nextEpisode() }
        binding.btnRewind.setOnClickListener { player?.seekTo((player!!.currentPosition - 10000).coerceAtLeast(0)) }
        binding.btnForward.setOnClickListener { player?.seekTo(player!!.currentPosition + 10000) }
        binding.btnBack.setOnClickListener { saveProgress(); finish() }
        binding.btnFullscreen.setOnClickListener { toggleSidePanel() }

        // زر CC - كليك: تشغيل/إيقاف أو اختيار ملف
        binding.btnCc.setOnClickListener {
            if (subtitles.isNotEmpty()) {
                subtitlesEnabled = !subtitlesEnabled
                if (!subtitlesEnabled) binding.tvSubtitle.text = ""
                updateCcButton()
                showToast(if (subtitlesEnabled) "CC On ✅" else "CC Off ⭕")
            } else {
                pickSubtitleFile()
            }
        }

        // زر CC - طويل: فتح إعدادات الترجمة
        binding.btnCc.setOnLongClickListener {
            toggleSubSettings()
            true
        }

        // SeekBar الفيديو
        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val duration = player?.duration ?: 0L
                    player?.seekTo((progress / 100.0 * duration).toLong())
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // SeekBar حجم الترجمة
        binding.seekSubSize.progress = 13 // يعادل 26f
        binding.seekSubSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                subtitleFontSize = 14f + progress * 2f
                binding.tvSubtitle.textSize = subtitleFontSize
                binding.tvSubSize.text = "${subtitleFontSize.toInt()}"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // SeekBar تأخير الترجمة (0 = -5s, 20 = 0s, 40 = +5s)
        binding.seekSubDelay.max = 40
        binding.seekSubDelay.progress = 20
        binding.seekSubDelay.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                // كل خطوة = 250ms، الوسط = 0
                val steps = progress - 20
                subtitleDelayMs = steps * 250L
                // snap إلى 500ms
                subtitleDelayMs = (subtitleDelayMs / 500L) * 500L
                val sec = subtitleDelayMs / 1000.0
                binding.tvSubDelay.text = when {
                    sec == 0.0 -> "0.0s"
                    sec > 0 -> "+${"%.1f".format(sec)}s"
                    else -> "${"%.1f".format(sec)}s"
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        binding.btnSubDelayReset.setOnClickListener {
            subtitleDelayMs = 0L
            binding.seekSubDelay.progress = 20
            binding.tvSubDelay.text = "0.0s"
        }

        // بدء تحديث الترجمة والتقدم
        handler.post(subtitleRunnable)
        handler.post(saveRunnable)
        handler.post(updateProgressRunnable)
    }

    private val updateProgressRunnable = object : Runnable {
        override fun run() {
            val duration = player?.duration ?: 0L
            val position = player?.currentPosition ?: 0L
            if (duration > 0) {
                binding.seekBar.progress = (position * 100 / duration).toInt()
                binding.tvCurrentTime.text = formatTime(position)
                binding.tvDuration.text = formatTime(duration)
            }
            handler.postDelayed(this, 500)
        }
    }

    private fun updateSubtitle() {
        if (!subtitlesEnabled || subtitles.isEmpty()) {
            binding.tvSubtitle.text = ""
            return
        }
        val pos = player?.currentPosition ?: 0L
        binding.tvSubtitle.text = SubtitleParser.getSubtitleAt(subtitles, pos, subtitleDelayMs)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                toggleControls()
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                // double tap يمين = تقديم، يسار = ترجيع
                val halfWidth = binding.playerView.width / 2
                if (e.x > halfWidth) {
                    player?.seekTo((player!!.currentPosition + 10000))
                    showToast("+10s ⏩")
                } else {
                    player?.seekTo((player!!.currentPosition - 10000).coerceAtLeast(0))
                    showToast("-10s ⏪")
                }
                return true
            }
        })
        binding.playerView.setOnTouchListener { _, event -> detector.onTouchEvent(event); true }
    }

    private fun toggleControls() {
        if (controlsVisible) hideControls() else showControls()
    }

    private fun showControls() {
        controlsVisible = true
        binding.layoutControls.visibility = View.VISIBLE
        binding.layoutControls.animate().alpha(1f).setDuration(200).start()
        handler.removeCallbacks(hideControlsRunnable)
        if (player?.isPlaying == true) handler.postDelayed(hideControlsRunnable, 3000)
    }

    private fun hideControls() {
        controlsVisible = false
        binding.layoutControls.animate().alpha(0f).setDuration(300).withEndAction {
            binding.layoutControls.visibility = View.GONE
        }.start()
    }

    private fun toggleSidePanel() {
        val panel = binding.layoutSidePanel
        if (panel.visibility == View.VISIBLE) {
            panel.animate().translationX(-panel.width.toFloat()).setDuration(250).withEndAction {
                panel.visibility = View.GONE
            }.start()
        } else {
            panel.visibility = View.VISIBLE
            panel.translationX = -panel.width.toFloat()
            panel.animate().translationX(0f).setDuration(250).start()
        }
    }

    private fun toggleSubSettings() {
        val panel = binding.layoutSubSettings
        panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun togglePlayPause() {
        if (player?.isPlaying == true) player?.pause() else player?.play()
    }

    private fun updatePlayPauseBtn() {
        binding.btnPlayPause.text = if (player?.isPlaying == true) "⏸" else "▶"
    }

    private fun updateCcButton() {
        if (subtitlesEnabled && subtitles.isNotEmpty()) {
            binding.btnCc.alpha = 1f
            binding.btnCc.setTextColor(getColor(R.color.orange))
        } else {
            binding.btnCc.alpha = 0.5f
            binding.btnCc.setTextColor(getColor(android.R.color.white))
        }
    }

    private fun pickSubtitleFile() {
        pickSubtitleLauncher.launch("*/*")
    }

    private fun nextEpisode() {
        if (currentEpisodeIndex < episodes.size - 1) {
            playEpisode(currentEpisodeIndex + 1)
        } else if (currentSeasonIndex < seasons.size - 1) {
            binding.spinnerSeasons.setSelection(currentSeasonIndex + 1)
        } else showToast("End of Series")
    }

    private fun prevEpisode() {
        if (currentEpisodeIndex > 0) {
            playEpisode(currentEpisodeIndex - 1)
        } else if (currentSeasonIndex > 0) {
            binding.spinnerSeasons.setSelection(currentSeasonIndex - 1)
        } else showToast("Start of Series")
    }

    private fun onEpisodeEnded() {
        seriesItem.episodesProgress[episodes[currentEpisodeIndex].fullPath] = 0.0
        saveProgress()
        // تشغيل الحلقة التالية تلقائياً
        handler.postDelayed({ nextEpisode() }, 1000)
    }

    private fun saveProgress() {
        val ep = episodes.getOrNull(currentEpisodeIndex) ?: return
        val pos = player?.currentPosition?.toDouble() ?: 0.0
        seriesItem.episodesProgress[ep.fullPath] = pos
        seriesItem.lastEpisodePath = ep.fullPath

        val allSeries = DataManager.loadSeries(this).toMutableList()
        val idx = allSeries.indexOfFirst { it.id == seriesItem.id }
        if (idx >= 0) allSeries[idx] = seriesItem else allSeries.add(seriesItem)
        DataManager.saveSeries(this, allSeries)
    }

    private fun formatTime(ms: Long): String {
        val totalSec = ms / 1000
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
        saveProgress()
        handler.removeCallbacks(hideControlsRunnable)
    }

    override fun onResume() {
        super.onResume()
        hideSystemUI()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
    }
}
