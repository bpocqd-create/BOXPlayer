package com.box.player.utils

import android.content.Context
import com.box.player.model.SeriesItem
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object DataManager {

    private const val PREFS_NAME = "BOXPlayerData"
    private const val KEY_SERIES = "series_list"
    private val gson = Gson()

    fun loadSeries(context: Context): MutableList<SeriesItem> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_SERIES, null) ?: return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<SeriesItem>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun saveSeries(context: Context, list: List<SeriesItem>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_SERIES, gson.toJson(list)).apply()
    }
}
