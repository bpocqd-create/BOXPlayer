package com.box.player.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.box.player.R
import com.box.player.databinding.ActivityMainBinding
import com.box.player.databinding.ItemSeriesBinding
import com.box.player.model.SeriesItem
import com.box.player.utils.DataManager
import java.io.File
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val seriesList = mutableListOf<SeriesItem>()
    private lateinit var adapter: SeriesAdapter

    private val pickFolderLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri?.let { addSeriesFromUri(it) }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) addSeries()
        else Toast.makeText(this, "Storage permission required", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        seriesList.addAll(DataManager.loadSeries(this))

        adapter = SeriesAdapter(seriesList,
            onItemClick = { series -> openPlayer(series) },
            onItemLongClick = { series -> showDeleteDialog(series) }
        )

        binding.rvSeries.layoutManager = GridLayoutManager(this, 2)
        binding.rvSeries.adapter = adapter

        binding.fabAdd.setOnClickListener { checkPermissionsAndAdd() }

        updateEmptyState()
    }

    private fun checkPermissionsAndAdd() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)
                == PackageManager.PERMISSION_GRANTED) {
                addSeries()
            } else {
                permissionLauncher.launch(arrayOf(Manifest.permission.READ_MEDIA_VIDEO))
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED) {
                addSeries()
            } else {
                permissionLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE))
            }
        }
    }

    private fun addSeries() {
        pickFolderLauncher.launch(null)
    }

    private fun addSeriesFromUri(uri: Uri) {
        val docFile = DocumentFile.fromTreeUri(this, uri) ?: return
        val name = docFile.name ?: "Unknown Series"

        // نحول URI لمسار حقيقي
        val path = getPathFromUri(uri)
        if (path == null) {
            Toast.makeText(this, "Cannot read this folder. Try selecting from internal storage.", Toast.LENGTH_LONG).show()
            return
        }

        if (seriesList.any { it.path == path }) {
            Toast.makeText(this, "$name already added", Toast.LENGTH_SHORT).show()
            return
        }

        val series = SeriesItem(
            id = UUID.randomUUID().toString(),
            name = name,
            path = path
        )
        seriesList.add(series)
        DataManager.saveSeries(this, seriesList)
        adapter.notifyItemInserted(seriesList.size - 1)
        updateEmptyState()
        Toast.makeText(this, "✅ Added: $name", Toast.LENGTH_SHORT).show()
    }

    private fun getPathFromUri(uri: Uri): String? {
        try {
            val docId = DocumentsContract.getTreeDocumentId(uri)
            if (docId.startsWith("primary:")) {
                val relativePath = docId.removePrefix("primary:")
                val path = "${Environment.getExternalStorageDirectory()}/$relativePath"
                if (File(path).exists()) return path
            }
            // محاولة بديلة
            val path = uri.path ?: return null
            val parts = path.split(":")
            if (parts.size >= 2) {
                val candidate = "/storage/emulated/0/${parts.last()}"
                if (File(candidate).exists()) return candidate
            }
        } catch (e: Exception) { }
        return null
    }

    private fun showDeleteDialog(series: SeriesItem) {
        AlertDialog.Builder(this)
            .setTitle("Remove Series")
            .setMessage("Remove \"${series.name}\" from the list?\n(Files won't be deleted)")
            .setPositiveButton("Remove") { _, _ ->
                val idx = seriesList.indexOf(series)
                seriesList.remove(series)
                DataManager.saveSeries(this, seriesList)
                adapter.notifyItemRemoved(idx)
                updateEmptyState()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openPlayer(series: SeriesItem) {
        val intent = Intent(this, PlayerActivity::class.java)
        intent.putExtra("series_id", series.id)
        intent.putExtra("series_path", series.path)
        intent.putExtra("series_name", series.name)
        startActivity(intent)
    }

    private fun updateEmptyState() {
        binding.tvEmpty.visibility = if (seriesList.isEmpty()) View.VISIBLE else View.GONE
        binding.rvSeries.visibility = if (seriesList.isEmpty()) View.GONE else View.VISIBLE
    }

    override fun onResume() {
        super.onResume()
        val updated = DataManager.loadSeries(this)
        seriesList.clear()
        seriesList.addAll(updated)
        adapter.notifyDataSetChanged()
    }
}

// ==================== Adapter ====================

class SeriesAdapter(
    private val items: List<SeriesItem>,
    private val onItemClick: (SeriesItem) -> Unit,
    private val onItemLongClick: (SeriesItem) -> Unit
) : RecyclerView.Adapter<SeriesAdapter.VH>() {

    inner class VH(val binding: ItemSeriesBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemSeriesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.tvName.text = item.name

        // عرض آخر حلقة
        if (item.lastEpisodePath.isNotEmpty()) {
            holder.binding.tvLastEp.text = "▶ ${File(item.lastEpisodePath).nameWithoutExtension}"
            holder.binding.tvLastEp.visibility = View.VISIBLE
        } else {
            holder.binding.tvLastEp.visibility = View.GONE
        }

        holder.binding.root.setOnClickListener { onItemClick(item) }
        holder.binding.root.setOnLongClickListener { onItemLongClick(item); true }
    }

    override fun getItemCount() = items.size
}
