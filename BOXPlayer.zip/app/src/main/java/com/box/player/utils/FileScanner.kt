package com.box.player.utils

import com.box.player.model.EpisodeInfo
import com.box.player.model.SeasonInfo
import java.io.File

object FileScanner {

    private val VIDEO_EXTENSIONS = setOf("mp4", "mkv", "avi", "wmv", "mov", "m4v", "3gp", "flv", "webm")
    private val SUBTITLE_EXTENSIONS = setOf("srt", "ass", "ssa")

    fun hasVideoFiles(dir: File): Boolean {
        return try {
            dir.listFiles()?.any { it.isFile && it.extension.lowercase() in VIDEO_EXTENSIONS } == true
        } catch (e: Exception) { false }
    }

    fun findVideoFolders(dir: File, results: MutableList<File> = mutableListOf()): List<File> {
        try {
            if (hasVideoFiles(dir) && !results.contains(dir)) results.add(dir)
            dir.listFiles()?.filter { it.isDirectory }?.forEach { findVideoFolders(it, results) }
        } catch (e: Exception) { }
        return results
    }

    fun detectSeasonNumber(dir: File): Int {
        val name = dir.name.lowercase()
        val matchS = Regex("""(season|s|series)\s*(\d+)""").find(name)
        if (matchS != null) return matchS.groupValues[2].toIntOrNull() ?: 9999
        name.toIntOrNull()?.let { return it }
        try {
            dir.listFiles()
                ?.filter { it.extension.lowercase() in VIDEO_EXTENSIONS }
                ?.take(5)
                ?.forEach { f ->
                    val fn = f.nameWithoutExtension.lowercase()
                    Regex("""s(\d+)e\d+""").find(fn)?.let { return it.groupValues[1].toInt() }
                    Regex("""(\d+)x\d+""").find(fn)?.let { return it.groupValues[1].toInt() }
                }
        } catch (e: Exception) { }
        return 9999
    }

    fun loadSeasons(rootPath: String): List<SeasonInfo> {
        val root = File(rootPath)
        if (!root.exists()) return emptyList()

        val videoFolders = findVideoFolders(root).toMutableList()
        if (videoFolders.isEmpty() && hasVideoFiles(root)) videoFolders.add(root)

        val sorted = videoFolders
            .map { it to detectSeasonNumber(it) }
            .sortedBy { it.second }

        val seasons = mutableListOf<SeasonInfo>()
        var counter = 1
        for ((dir, num) in sorted) {
            val name = if (num != 9999) "Season $num" else "Season $counter"
            val finalName = if (seasons.any { it.displayName == name }) "$name (${dir.name})" else name
            seasons.add(SeasonInfo(finalName, dir.absolutePath))
            if (num == 9999) counter++ else counter = num + 1
        }
        return seasons
    }

    fun loadEpisodes(seasonPath: String): List<EpisodeInfo> {
        val dir = File(seasonPath)
        if (!dir.exists()) return emptyList()

        val files = dir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in VIDEO_EXTENSIONS }
            ?.sortedBy { extractEpisodeNumber(it.nameWithoutExtension) }
            ?: return emptyList()

        val episodes = mutableListOf<EpisodeInfo>()
        var counter = 1
        for (f in files) {
            val num = extractEpisodeNumber(f.nameWithoutExtension)
            val display = if (num != 99999) "Episode $num" else "Episode $counter"
            episodes.add(EpisodeInfo(display, f.absolutePath))
            counter++
        }
        return episodes
    }

    fun extractEpisodeNumber(fileName: String): Int {
        val fn = fileName.lowercase()
        Regex("""[s]\d+[e](\d+)""").find(fn)?.let { return it.groupValues[1].toInt() }
        Regex("""\d+[x](\d+)""").find(fn)?.let { return it.groupValues[1].toInt() }
        Regex("""(episode|ep)\.?\s*(\d+)""").find(fn)?.let { return it.groupValues[2].toInt() }
        Regex("""[\s\-_\[\(](\d+)($|\s|\.)""").find(fn)?.let { return it.groupValues[1].toInt() }
        return 99999
    }

    // البحث عن ملف الترجمة تلقائياً
    fun findSubtitleForVideo(videoPath: String): File? {
        val videoFile = File(videoPath)
        val dir = videoFile.parentFile ?: return null
        val baseName = videoFile.nameWithoutExtension

        // نفس الاسم أولاً
        for (ext in SUBTITLE_EXTENSIONS) {
            val candidate = File(dir, "$baseName.$ext")
            if (candidate.exists()) return candidate
        }
        // أي ملف ترجمة في المجلد
        return dir.listFiles()?.firstOrNull { it.extension.lowercase() in SUBTITLE_EXTENSIONS }
    }
}
